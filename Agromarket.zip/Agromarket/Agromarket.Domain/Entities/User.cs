namespace Agromarket.Domain.Entities;

public class User
{
    public Guid Id { get; set; }

    public string Email { get; set; } = string.Empty;

    public string PasswordHash { get; set; } = string.Empty;

    public bool IsActive { get; set; } = true;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public Guid RoleId { get; set; }

    public Role Role { get; set; } = null!;

    public UserProfile? Profile { get; set; }

    public ICollection<Publication> Publications { get; set; }
        = new List<Publication>();
}